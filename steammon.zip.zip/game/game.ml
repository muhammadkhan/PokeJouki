open Definitions
open Util
open Constants
open Netgraphics

(* You have to implement this. Change it from int to yout own state type*)
type game = int 

let game_datafication g =
	failwith "not implemented"
	
let game_from_data game_data = 
	failwith "not implemented"

let handle_step g ra ba =
	failwith "implement me!"

let init_game () =
	failwith "implement me!"